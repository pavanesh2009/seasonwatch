<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
   "http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>GlusterFS Login</title>

  <!-- Framework CSS -->
	<link rel="stylesheet" href="blueprint/screen.css" type="text/css" media="screen, projection">
	<link rel="stylesheet" href="blueprint/print.css" type="text/css" media="print">
  <!--[if IE]><link rel="stylesheet" href="../../blueprint/ie.css" type="text/css" media="screen, projection"><![endif]-->
</head>
<body>

	<div class="container">
				
    
    <div class="span-12" style="background-color: #4374b1">
    
      <form id="dummy" action="" method="post">
	<div class="box" style="color:#ffffff; background-color: #4374b1; padding-bottom:0px;">
      
      		

      		<p><label for="username">Username</label><br>
      		  <input type="text" class="title" name="dummy0" id="dummy0" value=""></p>
        
          <p><label for="password">Password</label><br>
      		  <input type="text" class="text" id="dummy1" name="dummy1" value=""></p>

      	  <!--<label for="dummy2">Textarea</label><br>
      	    <textarea name="dummy2" id="dummy2" rows="5" cols="20"></textarea>-->

      		<p><input type="submit" value="Submit">
      		  <input type="reset" value="Reset"></p>

      	</div>
      </form>
    
    </div><!--
    <div class="span-12 last">
    
      <div class="error">
        This is a &lt;div&gt; with the class <strong>.error</strong>. <a href="#">Link</a>.
      </div>
      <div class="notice">
        This is a &lt;div&gt; with the class <strong>.notice</strong>. <a href="#">Link</a>.
      </div>		
      <div class="success">
        This is a &lt;div&gt; with the class <strong>.success</strong>. <a href="#">Link</a>.
      </div>    
      
      <fieldset>
        <legend>Select, checkboxes, lists</legend>

    		<p><label for="dummy3">Select field</label><br>
    		  <select id="dummy3" name="dummy3">
    			  <option value="1">Ottawa</option>
    			  <option value="2">Calgary</option>
    			  <option value="3">Moosejaw</option>
    		  </select></p>

    		<p><label for="dummy4">Select with groups</label><br>
    		  <select id="dummy4" name="dummy4">
    			  <option>Favorite pet</option>
    			  <optgroup label="mammals">
    			    <option>dog</option>
    			    <option>cat</option>
    			    <option>rabbit</option>
    			    <option>horse</option>
    			  </optgroup>
    			  <optgroup label="reptiles">
    			    <option>iguana</option>
    			    <option>snake</option>
    			  </optgroup>
    		  </select></p>
    		  
    		  <p><label>Radio buttons</label><br>
    		    <input type="radio" name="example"> Radio one<br>
    		    <input type="radio" name="example"> Radio two<br>
    		    <input type="radio" name="example"> Radio three<br></p>
          
    		  <p><label>Checkboxes</label><br>
    		    <input type="checkbox"> Check one<br>
    		    <input type="checkbox"> Check two<br>
    		    <input type="checkbox"> Check three<br></p>
        
      </fieldset>
    
    </div>
    <hr>

    <p><a href="http://validator.w3.org/check?uri=referer">
    <img src="valid.png" alt="Valid HTML 4.01 Strict" height="31" width="88" class="top"></a></p>
    -->
  </div>
</body>
</html>
