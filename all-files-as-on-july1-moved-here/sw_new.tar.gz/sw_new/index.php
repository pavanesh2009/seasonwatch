<? 
   session_start();
   $page_title="SeasonWatch";
   include("main_includes.php");
?>
<body>
<? 
	include("header.php");
?>
<div class='container first_image'>
     Sample seasonwatch page

     You can add the content here
     
</div>
</div>
</div>
<div class="container bottom">
</div>
<?php 
   include("footer.php");
?>
</body>
</html>
