<head><title>Species Master Page</title></head>
<small style="font-family: Helvetica,Arial,sans-serif;">
<map name="Map">
<!--Add here Related link for HotSpots-->
<area shape="rect" coords="64, 180, 192, 220" href="admin_logout.php">
</map>

<img style="border-style: none;" alt="SeasonWatch banner" src="../images/speciesmaster.png" usemap="#Map"><br>

</small>
