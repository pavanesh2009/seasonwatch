<?php 
?>
<html>
<head>
</head>
<div class="container top">
</div>
<div class="container bottom">
</div>
</body>
</html>