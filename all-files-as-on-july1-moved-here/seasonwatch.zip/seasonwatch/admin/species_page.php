<html>

    <frameset cols="60,30">
        <frame src="addspecies.php">
        <frame src="species_reference.php">
    </frameset>

</html>
